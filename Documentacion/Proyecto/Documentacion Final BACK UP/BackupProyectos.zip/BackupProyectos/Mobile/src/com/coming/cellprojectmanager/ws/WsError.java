package com.coming.cellprojectmanager.ws;

public class WsError {
	public Integer codigo;
	public String descripcion;
}
