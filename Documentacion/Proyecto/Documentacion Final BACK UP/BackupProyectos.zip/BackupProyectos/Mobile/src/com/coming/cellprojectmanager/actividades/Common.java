package com.coming.cellprojectmanager.actividades;

public class Common {
	protected static final String EXTRAS_KEY_ACONTECIMIENTO = "acontecimiento";
	protected static final String EXTRAS_KEY_SITIO = "sitio";
	protected static final String EXTRAS_KEY_TAREA = "tarea";
}
