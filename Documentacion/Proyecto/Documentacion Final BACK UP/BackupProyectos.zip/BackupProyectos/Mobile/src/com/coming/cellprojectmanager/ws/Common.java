package com.coming.cellprojectmanager.ws;

public class Common {
	public static final String WS_URL = "http://10.0.2.2:8080/CellProjectManager/";
	public static final String WS_SITIOS = "mobile/sitios/";
	public static final String WS_TAREAS = "mobile/tareas/";
	public static final String WS_ACONTECIMIENTOS = "mobile/acontecimientos/";
	public static final String WS_TIPOS_ACONTECIMIENTOS = "mobile/tipoAcontecimientos/";
	public static final String WS_LOGIN = "mobile/restLogin/";
}
